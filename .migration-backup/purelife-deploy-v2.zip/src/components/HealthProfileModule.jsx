import { useState, useEffect, useRef, useCallback } from "react";

/* ═══════════════════════════════════════
   DESIGN TOKENS
═══════════════════════════════════════ */
const C = {
  bg0:"#02060a", bg1:"#060d0a", bg2:"#0a1410", bg3:"#0e1c16",
  green:"#2dff8c", teal:"#00e5c8", gold:"#d4a843", red:"#ff5757",
  white:"#f0ede6", muted:"#3d5449",
  glass:"rgba(13,26,19,0.85)", border:"rgba(45,255,140,0.12)",
};

/* ═══════════════════════════════════════
   GLOBAL CSS
═══════════════════════════════════════ */
const injectCSS = () => {
  if (document.getElementById("hp-css")) return;
  const s = document.createElement("style");
  s.id = "hp-css";
  s.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Syne:wght@700;800;900&family=Satoshi:wght@300;400;500;700;900&display=swap');
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
    html{scroll-behavior:smooth}
    body{background:${C.bg0};color:${C.white};font-family:'Satoshi',system-ui,sans-serif;overflow-x:hidden}
    ::-webkit-scrollbar{width:3px}::-webkit-scrollbar-track{background:#030806}::-webkit-scrollbar-thumb{background:rgba(45,255,140,0.3);border-radius:2px}
    @keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
    @keyframes fadeIn{from{opacity:0}to{opacity:1}}
    @keyframes pulse{0%{box-shadow:0 0 0 0 rgba(45,255,140,0.5)}70%{box-shadow:0 0 0 10px rgba(45,255,140,0)}100%{box-shadow:0 0 0 0 rgba(45,255,140,0)}}
    @keyframes spin{to{transform:rotate(360deg)}}
    @keyframes scan{0%{top:-2%}100%{top:102%}}
    @keyframes floatY{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
    @keyframes blink{0%,100%{opacity:1}50%{opacity:0.3}}
    @keyframes barGrow{from{width:0}to{width:var(--w)}}
    @keyframes shimmer{0%{background-position:-200% 0}100%{background-position:200% 0}}
    @keyframes ring{0%{stroke-dashoffset:var(--from)}100%{stroke-dashoffset:var(--to)}}
    .hp-btn-p{padding:12px 28px;border-radius:10px;border:none;background:${C.green};color:#020a06;font-size:13px;font-weight:800;cursor:pointer;transition:all .25s;font-family:'Satoshi',sans-serif;box-shadow:0 0 28px rgba(45,255,140,0.3);letter-spacing:.01em}
    .hp-btn-p:hover{background:#4fffa8;box-shadow:0 0 44px rgba(45,255,140,0.55);transform:translateY(-1px)}
    .hp-btn-p:disabled{opacity:0.4;cursor:not-allowed;transform:none;box-shadow:none}
    .hp-btn-g{padding:11px 24px;border-radius:10px;border:1px solid rgba(45,255,140,0.25);background:transparent;color:${C.green};font-size:13px;font-weight:600;cursor:pointer;transition:all .25s;font-family:'Satoshi',sans-serif}
    .hp-btn-g:hover{background:rgba(45,255,140,0.06);border-color:rgba(45,255,140,0.4)}
    .hp-input{width:100%;padding:14px 18px;border-radius:12px;border:1px solid rgba(45,255,140,0.15);background:rgba(255,255,255,0.03);color:${C.white};font-size:15px;outline:none;font-family:'Satoshi',sans-serif;transition:border-color .25s}
    .hp-input:focus{border-color:rgba(45,255,140,0.4);background:rgba(45,255,140,0.03)}
    .hp-select-card{border-radius:12px;border:1px solid rgba(255,255,255,0.07);background:rgba(255,255,255,0.03);padding:12px 16px;cursor:pointer;transition:all .2s;font-size:13px;color:rgba(240,237,230,0.65)}
    .hp-select-card:hover{border-color:rgba(45,255,140,0.3);background:rgba(45,255,140,0.05);color:${C.white}}
    .hp-select-card.sel{border-color:rgba(45,255,140,0.5);background:rgba(45,255,140,0.08);color:${C.green}}
    .hp-checkbox{border-radius:10px;border:1px solid rgba(255,255,255,0.07);background:rgba(255,255,255,0.02);padding:10px 14px;cursor:pointer;transition:all .2s;font-size:12px;color:rgba(240,237,230,0.6);display:flex;align-items:center;gap:8px}
    .hp-checkbox:hover{border-color:rgba(45,255,140,0.25);color:${C.white}}
    .hp-checkbox.sel{border-color:rgba(45,255,140,0.45);background:rgba(45,255,140,0.07);color:${C.green}}
    .hp-scale-btn{width:40px;height:40px;border-radius:50%;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.03);cursor:pointer;font-size:12px;font-weight:700;color:rgba(240,237,230,0.5);transition:all .2s;display:flex;align-items:center;justify-content:center}
    .hp-scale-btn:hover{border-color:rgba(45,255,140,0.3);color:${C.white}}
    .hp-scale-btn.sel{border-color:rgba(45,255,140,0.5);background:rgba(45,255,140,0.1);color:${C.green};box-shadow:0 0 16px rgba(45,255,140,0.2)}
    .smooshie-card{background:rgba(255,255,255,0.03);border:1px solid rgba(45,255,140,0.1);border-radius:16px;padding:16px;transition:all .3s}
    .smooshie-card:hover{border-color:rgba(45,255,140,0.25);background:rgba(45,255,140,0.04);transform:translateY(-2px)}
    .alert-item{display:flex;gap:10px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.04);align-items:flex-start}
    .alert-item:last-child{border-bottom:none}
  `;
  document.head.appendChild(s);
};

/* ═══════════════════════════════════════
   CLAUDE API
═══════════════════════════════════════ */
async function askClaude(system, user, tokens = 1500) {
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: tokens,
      system,
      messages: [{ role: "user", content: user }],
    }),
  });
  if (!r.ok) throw new Error(`Claude error ${r.status}`);
  const d = await r.json();
  return d.content?.[0]?.text || "";
}

function extractJSON(text) {
  try {
    const m = text.match(/```json\s*([\s\S]*?)```/) || text.match(/\{[\s\S]*\}/);
    return JSON.parse(m ? (m[1] || m[0]) : text);
  } catch { return null; }
}

/* ═══════════════════════════════════════
   QUESTIONS DEFINITION
═══════════════════════════════════════ */
const BLOCKS = [
  {
    id: "identity", num: "01", title: "Datos personales",
    color: C.green, icon: "👤",
    desc: "Para personalizar cada recomendación con precisión",
    questions: [
      { id:"name",       type:"text",     label:"¿Cuál es tu nombre completo?",                           placeholder:"Ej: María González" },
      { id:"age",        type:"number",   label:"¿Qué edad tienes?",                                       placeholder:"Ej: 34",  unit:"años" },
      { id:"sex",        type:"select",   label:"Sexo biológico",                                          options:["Femenino","Masculino","Prefiero no decir"] },
      { id:"weight",     type:"number",   label:"Peso aproximado",                                          placeholder:"Ej: 68", unit:"kg" },
      { id:"height",     type:"number",   label:"Altura",                                                   placeholder:"Ej: 165", unit:"cm" },
      { id:"allergies",  type:"multi",    label:"¿Tienes alergias o intolerancias alimenticias?",
        options:["Ninguna","Gluten","Lactosa","Frutos secos","Mariscos","Huevo","Soya","Otro"] },
    ],
  },
  {
    id: "health", num: "02", title: "Estado de salud actual",
    color: C.gold, icon: "🩺",
    desc: "Condiciones presentes que guían tus recomendaciones",
    questions: [
      { id:"conditions", type:"multi",    label:"¿Tienes alguna condición de salud diagnosticada?",
        options:["Ninguna","Diabetes","Hipertensión","Colesterol alto","Tiroides","Gastritis","Anemia","Otra"] },
      { id:"medications",type:"textarea", label:"¿Tomas algún medicamento actualmente? ¿Cuál?",            placeholder:"Ej: metformina 500mg, losartán… o escribe 'Ninguno'" },
      { id:"energy",     type:"scale",    label:"¿Cómo describes tu nivel de energía diaria?",             scaleLabels:["Muy bajo","Bajo","Moderado","Alto","Muy alto"] },
      { id:"goal",       type:"multi",    label:"¿Cuál es tu objetivo principal de bienestar?",
        options:["Bajar peso","Más energía","Mejorar digestión","Reforzar inmunidad","Reducir inflamación","Equilibrio hormonal","Reducir estrés"] },
    ],
  },
  {
    id: "lifestyle", num: "03", title: "Genética y estilo de vida",
    color: C.teal, icon: "🧬",
    desc: "Historia familiar y hábitos que moldean tu plan",
    questions: [
      { id:"family",     type:"multi",    label:"¿Hay enfermedades en tu familia directa?",
        options:["Ninguna","Diabetes","Enfermedades cardíacas","Cáncer","Hipertensión","Alzheimer","Obesidad","Otra"] },
      { id:"substances", type:"select",   label:"¿Consumes tabaco, alcohol u otras sustancias?",
        options:["No consumo ninguna","Alcohol ocasional","Alcohol frecuente","Tabaco","Tabaco + alcohol","Cannabis u otras"] },
      { id:"diet",       type:"select",   label:"¿Cómo describes tu dieta habitual?",
        options:["Omnívora equilibrada","Omnívora con muchos procesados","Vegetariana","Vegana","Keto/low carb","Mediterránea","Sin orden específico"] },
      { id:"activity",   type:"select",   label:"¿Cuál es tu nivel de actividad física?",
        options:["Sedentario (sin ejercicio)","Ligero (1-2x semana)","Moderado (3-4x semana)","Activo (5-6x semana)","Atleta (diario)"] },
    ],
  },
  {
    id: "closing", num: "04", title: "Cierre del perfil",
    color: "#a78bfa", icon: "✦",
    desc: "Últimos datos que afinan tu plan al máximo",
    questions: [
      { id:"water",      type:"select",   label:"¿Cuánta agua bebes al día?",
        options:["Menos de 1 litro","Entre 1 y 2 litros","Más de 2 litros","Casi no tomo agua"] },
      { id:"stress",     type:"scale",    label:"¿Cómo describes tu nivel de estrés diario?",              scaleLabels:["Muy bajo","Bajo","Moderado","Alto","Muy alto"] },
      { id:"sleep",      type:"number",   label:"¿Cuántas horas duermes en promedio?",                      placeholder:"Ej: 7", unit:"horas" },
      { id:"extra",      type:"textarea", label:"¿Hay algo más que creas importante que el AI conozca?",    placeholder:"Cualquier cosa adicional sobre tu salud… o escribe 'Nada más'" },
    ],
  },
];

/* ═══════════════════════════════════════
   PROGRESS BAR
═══════════════════════════════════════ */
function ProgressBar({ current, total }) {
  const pct = Math.round((current / total) * 100);
  return (
    <div style={{ position:"fixed", top:0, left:0, right:0, zIndex:300, height:3, background:"rgba(255,255,255,0.05)" }}>
      <div style={{ height:"100%", width:`${pct}%`, background:`linear-gradient(90deg,${C.green},${C.teal})`, transition:"width 0.5s ease", boxShadow:`0 0 8px ${C.green}` }} />
    </div>
  );
}

/* ═══════════════════════════════════════
   QUESTION RENDERER
═══════════════════════════════════════ */
function QuestionInput({ q, value, onChange }) {
  if (q.type === "text" || q.type === "number") {
    return (
      <input
        className="hp-input"
        type={q.type === "number" ? "number" : "text"}
        placeholder={q.placeholder}
        value={value || ""}
        onChange={e => onChange(e.target.value)}
        style={{ fontSize:16 }}
      />
    );
  }
  if (q.type === "textarea") {
    return (
      <textarea
        className="hp-input"
        rows={3}
        placeholder={q.placeholder}
        value={value || ""}
        onChange={e => onChange(e.target.value)}
        style={{ resize:"vertical", lineHeight:1.6 }}
      />
    );
  }
  if (q.type === "select") {
    return (
      <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
        {q.options.map(opt => (
          <div key={opt} className={`hp-select-card${value === opt ? " sel" : ""}`} onClick={() => onChange(opt)}>
            <span style={{ marginRight:8 }}>{value === opt ? "●" : "○"}</span>{opt}
          </div>
        ))}
      </div>
    );
  }
  if (q.type === "multi") {
    const vals = Array.isArray(value) ? value : [];
    const toggle = opt => {
      const next = vals.includes(opt) ? vals.filter(v => v !== opt) : [...vals, opt];
      onChange(next);
    };
    return (
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
        {q.options.map(opt => (
          <div key={opt} className={`hp-checkbox${vals.includes(opt) ? " sel" : ""}`} onClick={() => toggle(opt)}>
            <span style={{ fontSize:14, flexShrink:0 }}>{vals.includes(opt) ? "✓" : "○"}</span>
            <span>{opt}</span>
          </div>
        ))}
      </div>
    );
  }
  if (q.type === "scale") {
    return (
      <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
        <div style={{ display:"flex", gap:10, justifyContent:"center" }}>
          {[1,2,3,4,5].map(n => (
            <div key={n} className={`hp-scale-btn${value === n ? " sel" : ""}`} onClick={() => onChange(n)}>
              {n}
            </div>
          ))}
        </div>
        <div style={{ display:"flex", justifyContent:"space-between", fontSize:10, color:C.muted, fontFamily:"'JetBrains Mono',monospace" }}>
          <span>{q.scaleLabels[0]}</span>
          <span>{q.scaleLabels[4]}</span>
        </div>
      </div>
    );
  }
  return null;
}

/* ═══════════════════════════════════════
   SCREEN: INTRO
═══════════════════════════════════════ */
function IntroScreen({ onStart }) {
  return (
    <div style={{ minHeight:"100vh", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"40px 24px", textAlign:"center", animation:"fadeIn 0.8s ease" }}>
      {/* Glow */}
      <div style={{ position:"fixed", top:"30%", left:"50%", transform:"translate(-50%,-50%)", width:600, height:600, background:"radial-gradient(ellipse,rgba(45,255,140,0.07) 0%,transparent 70%)", pointerEvents:"none" }} />
      {/* Avatar */}
      <div style={{ width:96, height:96, borderRadius:"50%", background:`linear-gradient(135deg,${C.bg2},${C.bg3})`, border:"2px solid rgba(45,255,140,0.4)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:44, marginBottom:28, boxShadow:"0 0 60px rgba(45,255,140,0.25)", animation:"floatY 4s ease-in-out infinite" }}>
        🧑‍⚕️
      </div>
      <div style={{ display:"inline-flex", alignItems:"center", gap:8, border:"1px solid rgba(45,255,140,0.2)", background:"rgba(45,255,140,0.05)", borderRadius:100, padding:"5px 14px 5px 8px", marginBottom:24 }}>
        <div style={{ width:7, height:7, borderRadius:"50%", background:C.green, animation:"pulse 2s infinite" }} />
        <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:10, fontWeight:700, color:C.green, letterSpacing:"0.1em", textTransform:"uppercase" }}>Dr. Smoothie · Perfil de Bienestar</span>
      </div>
      <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:"clamp(36px,5vw,62px)", fontWeight:900, letterSpacing:"-0.04em", lineHeight:1, color:C.white, marginBottom:20 }}>
        Tu diagnóstico<br/><span style={{ color:C.green }}>personalizado</span><br/>te espera.
      </h1>
      <p style={{ fontSize:15, color:"rgba(240,237,230,0.45)", lineHeight:1.8, maxWidth:480, marginBottom:40 }}>
        Responde <strong style={{ color:"rgba(240,237,230,0.8)" }}>18 preguntas clave</strong> sobre tu salud y estilo de vida.
        El Dr. Smoothie AI analizará tu perfil completo y diseñará un plan de
        <strong style={{ color:C.green }}> smoothies y jugos 100% personalizado</strong> para ti —
        más un video explicativo con tu hoja de ruta de bienestar.
      </p>
      <div style={{ display:"flex", gap:14, alignItems:"center", justifyContent:"center", flexWrap:"wrap", marginBottom:36 }}>
        {["~4 minutos","18 preguntas","4 bloques","Diagnóstico + Video"].map(t => (
          <span key={t} style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:10, color:C.muted, border:"1px solid rgba(255,255,255,0.06)", borderRadius:100, padding:"4px 12px" }}>{t}</span>
        ))}
      </div>
      <button className="hp-btn-p" style={{ fontSize:15, padding:"15px 36px" }} onClick={onStart}>
        Comenzar mi perfil ⚡
      </button>
      <p style={{ fontSize:11, color:C.muted, marginTop:20, maxWidth:360, lineHeight:1.6 }}>
        🔒 Tus datos son privados y encriptados. Esta herramienta ofrece orientación nutricional y de bienestar — no reemplaza la consulta médica profesional.
      </p>
    </div>
  );
}

/* ═══════════════════════════════════════
   SCREEN: WIZARD
═══════════════════════════════════════ */
function WizardScreen({ onComplete }) {
  const [blockIdx, setBlockIdx] = useState(0);
  const [qIdx, setQIdx]         = useState(0);
  const [answers, setAnswers]   = useState({});
  const [visible, setVisible]   = useState(true);

  const allQuestions = BLOCKS.flatMap(b => b.questions.map(q => ({ ...q, block: b })));
  const totalQ  = allQuestions.length;
  const flatIdx = BLOCKS.slice(0, blockIdx).reduce((acc, b) => acc + b.questions.length, 0) + qIdx;
  const block   = BLOCKS[blockIdx];
  const q       = block.questions[qIdx];
  const val     = answers[q.id];

  const canNext = () => {
    if (!val || val === "") return false;
    if (Array.isArray(val) && val.length === 0) return false;
    return true;
  };

  const animTo = (fn) => {
    setVisible(false);
    setTimeout(() => { fn(); setVisible(true); }, 280);
  };

  const next = () => {
    if (!canNext()) return;
    animTo(() => {
      if (qIdx < block.questions.length - 1) {
        setQIdx(qIdx + 1);
      } else if (blockIdx < BLOCKS.length - 1) {
        setBlockIdx(blockIdx + 1);
        setQIdx(0);
      } else {
        onComplete(answers);
      }
    });
  };

  const back = () => {
    if (flatIdx === 0) return;
    animTo(() => {
      if (qIdx > 0) setQIdx(qIdx - 1);
      else { setBlockIdx(blockIdx - 1); setQIdx(BLOCKS[blockIdx - 1].questions.length - 1); }
    });
  };

  return (
    <>
      <ProgressBar current={flatIdx + 1} total={totalQ} />
      <div style={{ minHeight:"100vh", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"80px 24px 40px" }}>
        <div style={{ width:"100%", maxWidth:560 }}>
          {/* Block header */}
          <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:32 }}>
            <div style={{ width:42, height:42, borderRadius:50, background:`rgba(${block.color===C.green?"45,255,140":block.color===C.gold?"212,168,67":block.color===C.teal?"0,229,200":"167,139,250"},0.08)`, border:`1px solid rgba(${block.color===C.green?"45,255,140":block.color===C.gold?"212,168,67":block.color===C.teal?"0,229,200":"167,139,250"},0.25)`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18 }}>
              {block.icon}
            </div>
            <div>
              <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, fontWeight:700, color:C.muted, textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:2 }}>Bloque {block.num} · {block.title}</div>
              <div style={{ fontSize:11, color:C.muted }}>{block.desc}</div>
            </div>
            <div style={{ marginLeft:"auto", fontFamily:"'JetBrains Mono',monospace", fontSize:12, color:block.color, fontWeight:700 }}>
              {flatIdx + 1}<span style={{ color:C.muted }}>/{totalQ}</span>
            </div>
          </div>

          {/* Question card */}
          <div style={{ background:C.glass, border:"1px solid rgba(45,255,140,0.1)", borderRadius:24, padding:"36px 32px", backdropFilter:"blur(24px)", boxShadow:"0 40px 80px rgba(0,0,0,0.5)", opacity:visible?1:0, transform:visible?"translateY(0)":"translateY(12px)", transition:"opacity 0.28s ease, transform 0.28s ease" }}>
            <h2 style={{ fontFamily:"'Syne',sans-serif", fontSize:22, fontWeight:800, letterSpacing:"-0.03em", color:C.white, marginBottom:8, lineHeight:1.2 }}>
              {q.label}
            </h2>
            {q.unit && <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:10, color:C.muted, marginBottom:20, textTransform:"uppercase", letterSpacing:"0.08em" }}>en {q.unit}</div>}
            {!q.unit && <div style={{ marginBottom:20 }} />}
            <QuestionInput
              q={q}
              value={val}
              onChange={v => setAnswers(prev => ({ ...prev, [q.id]: v }))}
            />
          </div>

          {/* Nav buttons */}
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginTop:20 }}>
            <button className="hp-btn-g" onClick={back} style={{ opacity:flatIdx===0?0.3:1 }} disabled={flatIdx===0}>← Anterior</button>
            <div style={{ display:"flex", gap:4 }}>
              {allQuestions.map((_, i) => (
                <div key={i} style={{ width:i===flatIdx?20:6, height:6, borderRadius:3, background:i<flatIdx?C.green:i===flatIdx?C.green:"rgba(255,255,255,0.1)", transition:"all 0.3s", opacity:i===flatIdx?1:0.6 }} />
              ))}
            </div>
            <button className="hp-btn-p" onClick={next} disabled={!canNext()} style={{ opacity:canNext()?1:0.4 }}>
              {flatIdx === totalQ - 1 ? "Analizar mi perfil 🤖" : "Siguiente →"}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

/* ═══════════════════════════════════════
   SCREEN: ANALYZING
═══════════════════════════════════════ */
function AnalyzingScreen({ name }) {
  const steps = ["Procesando tu historial de salud…","Evaluando factores genéticos y estilo de vida…","Identificando interacciones medicamento-ingrediente…","Generando tu plan de smoothies personalizado…","Calculando tu wellness score…","Preparando tu diagnóstico…"];
  const [step, setStep] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setStep(s => Math.min(s + 1, steps.length - 1)), 1200);
    return () => clearInterval(t);
  }, []);
  return (
    <div style={{ minHeight:"100vh", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"40px 24px", textAlign:"center" }}>
      <div style={{ position:"fixed", top:"40%", left:"50%", transform:"translate(-50%,-50%)", width:700, height:700, background:"radial-gradient(ellipse,rgba(45,255,140,0.06) 0%,transparent 70%)", pointerEvents:"none" }} />
      <div style={{ width:90, height:90, borderRadius:"50%", border:`3px solid rgba(45,255,140,0.3)`, borderTopColor:C.green, animation:"spin 1.2s linear infinite", marginBottom:36, boxShadow:`0 0 40px rgba(45,255,140,0.2)` }} />
      <h2 style={{ fontFamily:"'Syne',sans-serif", fontSize:28, fontWeight:900, letterSpacing:"-0.03em", color:C.white, marginBottom:8 }}>
        Analizando tu perfil<span style={{ color:C.green }}>…</span>
      </h2>
      <p style={{ fontSize:14, color:C.muted, marginBottom:36 }}>El Dr. Smoothie AI está diseñando tu plan personalizado</p>
      <div style={{ background:C.glass, border:"1px solid rgba(45,255,140,0.1)", borderRadius:18, padding:"24px 32px", backdropFilter:"blur(20px)", width:"100%", maxWidth:440 }}>
        {steps.map((s, i) => (
          <div key={i} style={{ display:"flex", alignItems:"center", gap:12, padding:"8px 0", borderBottom:i<steps.length-1?"1px solid rgba(255,255,255,0.04)":"none", opacity:i<=step?1:0.25, transition:"opacity 0.5s ease" }}>
            <div style={{ width:20, height:20, borderRadius:"50%", border:`1.5px solid ${i<step?C.green:i===step?"rgba(45,255,140,0.5)":"rgba(255,255,255,0.1)"}`, background:i<step?"rgba(45,255,140,0.15)":"transparent", display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, color:i<step?C.green:"transparent", flexShrink:0, transition:"all 0.4s" }}>
              {i < step ? "✓" : i === step ? <span style={{ animation:"blink 1s infinite" }}>●</span> : ""}
            </div>
            <span style={{ fontSize:12, color:i<=step?C.white:C.muted }}>{s}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════
   COMPONENT: WELLNESS RING
═══════════════════════════════════════ */
function WellnessRing({ score }) {
  const r = 54, circ = 2 * Math.PI * r;
  const offset = circ - (score / 100) * circ;
  const color = score >= 70 ? C.green : score >= 50 ? C.gold : C.red;
  return (
    <div style={{ position:"relative", width:130, height:130, flexShrink:0 }}>
      <svg width={130} height={130} viewBox="0 0 130 130" style={{ transform:"rotate(-90deg)" }}>
        <circle cx={65} cy={65} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={10} />
        <circle cx={65} cy={65} r={r} fill="none" stroke={color} strokeWidth={10}
          strokeDasharray={circ} strokeDashoffset={offset}
          strokeLinecap="round" style={{ transition:"stroke-dashoffset 1.5s ease", filter:`drop-shadow(0 0 8px ${color})` }} />
      </svg>
      <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center" }}>
        <div style={{ fontFamily:"'Syne',sans-serif", fontSize:30, fontWeight:900, color, lineHeight:1 }}>{score}</div>
        <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:8, color:C.muted, textTransform:"uppercase", letterSpacing:"0.08em", marginTop:3 }}>/ 100</div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════
   SCREEN: DIAGNOSIS DASHBOARD
═══════════════════════════════════════ */
function DiagnosisScreen({ diagnosis, answers, onGenerateVideo }) {
  const d = diagnosis;
  const scoreLabel = d.wellness_score >= 75 ? "Muy bueno" : d.wellness_score >= 60 ? "Moderado-bueno" : d.wellness_score >= 45 ? "Moderado" : "Necesita atención";
  const scoreColor = d.wellness_score >= 70 ? C.green : d.wellness_score >= 50 ? C.gold : C.red;

  return (
    <div style={{ padding:"80px 24px 60px", maxWidth:780, margin:"0 auto", animation:"fadeUp 0.7s ease" }}>

      {/* Header */}
      <div style={{ textAlign:"center", marginBottom:48 }}>
        <div style={{ display:"inline-flex", alignItems:"center", gap:8, border:"1px solid rgba(45,255,140,0.2)", background:"rgba(45,255,140,0.05)", borderRadius:100, padding:"5px 14px 5px 8px", marginBottom:20 }}>
          <div style={{ width:7, height:7, borderRadius:"50%", background:C.green, animation:"pulse 2s infinite" }} />
          <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:10, fontWeight:700, color:C.green, letterSpacing:"0.1em", textTransform:"uppercase" }}>Diagnóstico completado</span>
        </div>
        <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:38, fontWeight:900, letterSpacing:"-0.04em", color:C.white, marginBottom:8 }}>
          Hola, <span style={{ color:C.green }}>{answers.name || "miembro"}</span> 👋
        </h1>
        <p style={{ fontSize:14, color:C.muted }}>Tu perfil de bienestar personalizado está listo</p>
      </div>

      {/* Wellness score + summary */}
      <div style={{ background:C.glass, border:"1px solid rgba(45,255,140,0.12)", borderRadius:24, padding:"28px 28px", backdropFilter:"blur(24px)", marginBottom:16, display:"flex", gap:28, alignItems:"center", flexWrap:"wrap" }}>
        <WellnessRing score={d.wellness_score} />
        <div style={{ flex:1, minWidth:200 }}>
          <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:C.muted, textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:6 }}>Wellness Score</div>
          <div style={{ fontSize:22, fontWeight:800, color:scoreColor, marginBottom:8, letterSpacing:"-0.02em" }}>{scoreLabel}</div>
          <p style={{ fontSize:13, color:"rgba(240,237,230,0.6)", lineHeight:1.65 }}>{d.summary}</p>
        </div>
        {/* Quick stats */}
        <div style={{ display:"flex", flexDirection:"column", gap:8, flexShrink:0 }}>
          {[
            { label:"Edad", val:`${answers.age} años` },
            { label:"Peso/Talla", val:`${answers.weight}kg · ${answers.height}cm` },
            { label:"Objetivo", val:Array.isArray(answers.goal)?answers.goal[0]:answers.goal },
          ].map(s => (
            <div key={s.label} style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.06)", borderRadius:10, padding:"8px 14px", textAlign:"right" }}>
              <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:8, color:C.muted, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:2 }}>{s.label}</div>
              <div style={{ fontSize:11, fontWeight:700, color:C.white }}>{s.val}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Alerts */}
      {d.alerts && d.alerts.length > 0 && (
        <div style={{ background:"rgba(212,168,67,0.04)", border:"1px solid rgba(212,168,67,0.2)", borderRadius:18, padding:"20px 24px", marginBottom:16 }}>
          <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, fontWeight:700, color:C.gold, textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:14 }}>⚠️ Alertas de tu perfil</div>
          {d.alerts.map((a, i) => (
            <div key={i} className="alert-item">
              <span style={{ fontSize:18, flexShrink:0 }}>{a.icon || "⚠️"}</span>
              <div>
                <div style={{ fontSize:12, fontWeight:700, color:C.white, marginBottom:2 }}>{a.title}</div>
                <div style={{ fontSize:11, color:C.muted, lineHeight:1.5 }}>{a.detail}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Smoothie plan */}
      <div style={{ background:C.glass, border:"1px solid rgba(45,255,140,0.1)", borderRadius:18, padding:"22px 24px", backdropFilter:"blur(20px)", marginBottom:16 }}>
        <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, fontWeight:700, color:C.green, textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:16 }}>🍹 Tu plan de smoothies personalizado</div>
        <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
          {(d.smoothies || []).map((s, i) => (
            <div key={i} className="smooshie-card">
              <div style={{ display:"flex", alignItems:"flex-start", gap:12 }}>
                <div style={{ width:36, height:36, borderRadius:10, background:`rgba(45,255,140,0.08)`, border:`1px solid rgba(45,255,140,0.2)`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, flexShrink:0 }}>{s.emoji || "🥤"}</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:13, fontWeight:700, color:C.white, marginBottom:3 }}>{s.name}</div>
                  <div style={{ fontSize:11, color:C.muted, marginBottom:6, lineHeight:1.5 }}>{s.ingredients}</div>
                  <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                    <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, background:"rgba(45,255,140,0.08)", border:"1px solid rgba(45,255,140,0.15)", borderRadius:100, padding:"2px 8px", color:C.green }}>{s.timing}</span>
                    <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, background:"rgba(0,229,200,0.06)", border:"1px solid rgba(0,229,200,0.15)", borderRadius:100, padding:"2px 8px", color:C.teal }}>{s.benefit}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Avoid list */}
      {d.avoid && d.avoid.length > 0 && (
        <div style={{ background:"rgba(255,87,87,0.04)", border:"1px solid rgba(255,87,87,0.15)", borderRadius:14, padding:"14px 20px", marginBottom:24 }}>
          <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, fontWeight:700, color:C.red, textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:10 }}>🚫 Ingredientes a evitar en tu caso</div>
          <div style={{ display:"flex", flexWrap:"wrap", gap:7 }}>
            {d.avoid.map(a => (
              <span key={a} style={{ fontSize:11, background:"rgba(255,87,87,0.08)", border:"1px solid rgba(255,87,87,0.2)", borderRadius:100, padding:"4px 12px", color:C.red }}>{a}</span>
            ))}
          </div>
        </div>
      )}

      {/* Disclaimer */}
      <div style={{ background:"rgba(255,255,255,0.02)", border:"1px solid rgba(255,255,255,0.06)", borderRadius:12, padding:"12px 16px", marginBottom:32, fontSize:11, color:C.muted, lineHeight:1.6 }}>
        ⚕️ <strong style={{ color:"rgba(240,237,230,0.4)" }}>Orientación nutricional y de bienestar alternativo.</strong> Las recomendaciones de dr.smoothie.ai no constituyen diagnóstico médico y no reemplazan la consulta con tu médico. Consulta siempre a un profesional de la salud antes de realizar cambios en tu tratamiento.
      </div>

      {/* CTA Video */}
      <div style={{ background:`linear-gradient(135deg,rgba(45,255,140,0.06),rgba(0,229,200,0.04))`, border:"1px solid rgba(45,255,140,0.2)", borderRadius:20, padding:"28px 28px", textAlign:"center" }}>
        <div style={{ fontSize:36, marginBottom:12 }}>🎬</div>
        <h3 style={{ fontFamily:"'Syne',sans-serif", fontSize:22, fontWeight:800, letterSpacing:"-0.03em", color:C.white, marginBottom:8 }}>
          Tu video de diagnóstico está listo para generarse
        </h3>
        <p style={{ fontSize:13, color:C.muted, lineHeight:1.7, maxWidth:420, margin:"0 auto 24px" }}>
          El Dr. Smoothie te explicará en video tu plan completo, por qué es importante seguirlo, y qué resultados puedes esperar en <strong style={{ color:C.green }}>30, 60 y 90 días</strong>.
        </p>
        <button className="hp-btn-p" style={{ fontSize:14, padding:"14px 32px" }} onClick={onGenerateVideo}>
          🤖 Generar mi video personalizado
        </button>
        <div style={{ marginTop:16, display:"flex", gap:10, justifyContent:"center", flexWrap:"wrap" }}>
          {["🎭 Avatar Dr. Smoothie","🗣️ Voz personalizada","📲 Descargable","⏱️ ~90 segundos"].map(t => (
            <span key={t} style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:C.muted, border:"1px solid rgba(255,255,255,0.06)", borderRadius:100, padding:"3px 10px" }}>{t}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════
   SCREEN: VIDEO GENERATING
═══════════════════════════════════════ */
function VideoGeneratingScreen({ script, name }) {
  const [pct, setPct]   = useState(0);
  const [step, setStep] = useState(0);
  const vsteps = ["Claude genera el guión personalizado…","Enviando a HeyGen Avatar API…","Renderizando voz en español…","Sincronizando movimiento labial…","Aplicando branding dr.smoothie.ai…","Finalizando tu video 4K…"];
  useEffect(() => {
    let p = 0;
    const t = setInterval(() => {
      p += Math.random() * 3 + 1.5;
      if (p >= 100) { p = 100; clearInterval(t); }
      setPct(Math.round(Math.min(p, 100)));
      setStep(Math.min(Math.floor((p / 100) * vsteps.length), vsteps.length - 1));
    }, 600);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={{ minHeight:"100vh", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"40px 24px", textAlign:"center" }}>
      <div style={{ width:80, height:80, borderRadius:"50%", background:"rgba(45,255,140,0.08)", border:"2px solid rgba(45,255,140,0.3)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:36, marginBottom:28, animation:"floatY 3s ease-in-out infinite" }}>🎭</div>
      <h2 style={{ fontFamily:"'Syne',sans-serif", fontSize:28, fontWeight:900, letterSpacing:"-0.03em", color:C.white, marginBottom:8 }}>
        Generando tu video<span style={{ color:C.green }}>…</span>
      </h2>
      <p style={{ fontSize:13, color:C.muted, marginBottom:32 }}>El Dr. Smoothie está preparando tu mensaje personalizado</p>
      <div style={{ background:C.glass, border:"1px solid rgba(45,255,140,0.1)", borderRadius:18, padding:"24px 28px", backdropFilter:"blur(20px)", width:"100%", maxWidth:480, marginBottom:20 }}>
        <div style={{ display:"flex", justifyContent:"space-between", marginBottom:10 }}>
          <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:10, color:C.muted }}>HeyGen Avatar · ES · 1080p</span>
          <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:12, fontWeight:700, color:C.green }}>{pct}%</span>
        </div>
        <div style={{ height:4, background:"rgba(255,255,255,0.06)", borderRadius:2, overflow:"hidden", marginBottom:20 }}>
          <div style={{ height:"100%", width:`${pct}%`, background:`linear-gradient(90deg,${C.green},${C.teal})`, transition:"width 0.5s ease", boxShadow:`0 0 8px ${C.green}` }} />
        </div>
        {vsteps.map((s, i) => (
          <div key={i} style={{ display:"flex", gap:10, padding:"7px 0", borderBottom:i<vsteps.length-1?"1px solid rgba(255,255,255,0.04)":"none", opacity:i<=step?1:0.2, transition:"opacity 0.5s" }}>
            <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:10, color:i<step?C.green:i===step?C.green:C.muted, flexShrink:0 }}>{i<step?"✓":i===step?"⟳":"○"}</span>
            <span style={{ fontSize:11, color:i<step?C.white:C.muted, textAlign:"left" }}>{s}</span>
          </div>
        ))}
      </div>
      {/* Script preview */}
      {script && (
        <div style={{ background:"#020806", border:"1px solid rgba(45,255,140,0.1)", borderLeft:"3px solid rgba(45,255,140,0.4)", borderRadius:12, padding:"14px 18px", width:"100%", maxWidth:480, textAlign:"left" }}>
          <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:8, color:C.muted, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:8 }}>📝 Guión generado para {name}</div>
          <p style={{ fontSize:11, color:"rgba(240,237,230,0.55)", lineHeight:1.7, fontStyle:"italic" }}>"{script.substring(0, 280)}…"</p>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════
   SCREEN: VIDEO READY
═══════════════════════════════════════ */
function VideoReadyScreen({ script, name, answers, onRestart }) {
  const [playing, setPlaying] = useState(false);

  const timelines = [
    { t:"30 días", c:C.green, results:["Más energía al despertar","Mejor calidad del sueño","Hidratación mejorada"] },
    { t:"60 días", c:C.teal,  results:["Digestión optimizada","Reducción de inflamación","Hábito consolidado"] },
    { t:"90 días", c:C.gold,  results:["Peso en rango saludable","Glucosa estabilizada","Bienestar integral"] },
  ];

  return (
    <div style={{ padding:"80px 24px 60px", maxWidth:780, margin:"0 auto", animation:"fadeUp 0.7s ease" }}>

      {/* Header */}
      <div style={{ textAlign:"center", marginBottom:36 }}>
        <div style={{ fontSize:48, marginBottom:16 }}>✅</div>
        <h2 style={{ fontFamily:"'Syne',sans-serif", fontSize:34, fontWeight:900, letterSpacing:"-0.04em", color:C.white, marginBottom:8 }}>
          Tu video está <span style={{ color:C.green }}>listo</span>
        </h2>
        <p style={{ fontSize:14, color:C.muted }}>El Dr. Smoothie tiene un mensaje exclusivo para ti, {name}</p>
      </div>

      {/* Video player */}
      <div style={{ background:`linear-gradient(135deg,#030a06,#061410,#030a06)`, border:"1px solid rgba(45,255,140,0.12)", borderRadius:24, overflow:"hidden", position:"relative", aspectRatio:"16/9", display:"flex", alignItems:"center", justifyContent:"center", marginBottom:20, boxShadow:"0 40px 80px rgba(0,0,0,0.6)" }}>
        <div style={{ position:"absolute", inset:0, background:"radial-gradient(circle at 50% 55%,rgba(45,255,140,0.1) 0%,transparent 65%)" }} />
        <div style={{ position:"absolute", inset:0, backgroundImage:"repeating-linear-gradient(0deg,rgba(45,255,140,0.012) 0px,rgba(45,255,140,0.012) 1px,transparent 1px,transparent 4px)" }} />
        <div style={{ position:"absolute", top:0, left:0, right:0, height:2, background:"linear-gradient(90deg,transparent,rgba(45,255,140,0.5),transparent)", animation:"scan 3s linear infinite" }} />
        {/* Avatar */}
        <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:12, position:"relative", zIndex:2 }}>
          <div style={{ width:100, height:100, borderRadius:"50%", background:`linear-gradient(135deg,${C.bg2},${C.bg3})`, border:"3px solid rgba(45,255,140,0.4)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:48, boxShadow:"0 0 60px rgba(45,255,140,0.3)", animation:"floatY 3s ease-in-out infinite" }}>🧑‍⚕️</div>
          {!playing && (
            <button onClick={() => setPlaying(true)} style={{ width:52, height:52, borderRadius:"50%", background:"rgba(45,255,140,0.15)", border:"1.5px solid rgba(45,255,140,0.5)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, color:C.green, cursor:"pointer", boxShadow:"0 0 40px rgba(45,255,140,0.35)", animation:"floatY 2.5s ease-in-out infinite 0.5s" }}>▶</button>
          )}
        </div>
        {/* Badges */}
        <div style={{ position:"absolute", top:14, left:14, background:"rgba(2,6,10,0.85)", backdropFilter:"blur(10px)", border:"1px solid rgba(45,255,140,0.2)", borderRadius:8, padding:"5px 10px", fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:C.green, zIndex:3 }}>🎭 Dr. Smoothie Avatar</div>
        <div style={{ position:"absolute", top:14, right:14, background:"rgba(2,6,10,0.85)", backdropFilter:"blur(10px)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:8, padding:"5px 10px", fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"rgba(240,237,230,0.5)", zIndex:3 }}>1:30 · 1080p</div>
        {/* Subtitle */}
        <div style={{ position:"absolute", bottom:60, left:20, right:20, background:"rgba(2,6,10,0.9)", borderRadius:10, padding:"10px 16px", textAlign:"center", zIndex:3, fontSize:13, color:"rgba(240,237,230,0.85)", lineHeight:1.5, border:"1px solid rgba(255,255,255,0.05)" }}>
          "Tu plan personalizado está diseñado específicamente para tu perfil de salud y tus objetivos…"
        </div>
        {/* Bottom bar */}
        <div style={{ position:"absolute", bottom:0, left:0, right:0, background:"linear-gradient(0deg,rgba(2,6,10,0.95),transparent)", padding:"14px 20px", zIndex:3 }}>
          <div style={{ fontSize:13, fontWeight:700, color:C.white }}>Dr. Smoothie — Diagnóstico Personal · {name}</div>
          <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:C.green, marginTop:2, textTransform:"uppercase", letterSpacing:"0.06em" }}>Generado exclusivamente para tu perfil</div>
        </div>
      </div>

      {/* Script excerpt */}
      <div style={{ background:"#020806", border:"1px solid rgba(45,255,140,0.12)", borderLeft:"3px solid rgba(45,255,140,0.5)", borderRadius:14, padding:"16px 20px", marginBottom:20 }}>
        <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:C.muted, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:10 }}>📝 Guión de tu video · Generado por Claude</div>
        <p style={{ fontSize:12, color:"rgba(240,237,230,0.6)", lineHeight:1.8, fontStyle:"italic" }}>"{script}"</p>
      </div>

      {/* Share row */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:10, marginBottom:28 }}>
        {[["⬇️","Descargar MP4"],["📲","TikTok"],["📸","Reels"],["💬","WhatsApp"]].map(([i,l]) => (
          <button key={l} className="hp-btn-g" style={{ padding:"11px 8px", fontSize:11, display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
            <span style={{ fontSize:20 }}>{i}</span>{l}
          </button>
        ))}
      </div>

      {/* 30/60/90 timeline */}
      <div style={{ background:C.glass, border:"1px solid rgba(45,255,140,0.1)", borderRadius:20, padding:"24px 26px", backdropFilter:"blur(20px)", marginBottom:24 }}>
        <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, fontWeight:700, color:C.green, textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:20 }}>📅 Tu hoja de ruta — resultados esperados</div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:14 }}>
          {timelines.map(tl => (
            <div key={tl.t} style={{ background:"rgba(255,255,255,0.03)", border:`1px solid ${tl.c}30`, borderRadius:14, padding:"16px 14px", borderTop:`2px solid ${tl.c}` }}>
              <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:11, fontWeight:700, color:tl.c, marginBottom:12 }}>{tl.t}</div>
              {tl.results.map(r => (
                <div key={r} style={{ display:"flex", gap:6, alignItems:"flex-start", marginBottom:6, fontSize:11, color:"rgba(240,237,230,0.6)", lineHeight:1.4 }}>
                  <span style={{ color:tl.c, flexShrink:0, marginTop:1 }}>✓</span>{r}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* Disclaimer */}
      <div style={{ background:"rgba(255,255,255,0.02)", border:"1px solid rgba(255,255,255,0.05)", borderRadius:12, padding:"12px 16px", marginBottom:28, fontSize:11, color:C.muted, lineHeight:1.6, textAlign:"center" }}>
        ⚕️ Orientación nutricional y de bienestar alternativo — no reemplaza la consulta médica profesional. Consulta siempre a tu médico.
      </div>

      {/* Restart */}
      <div style={{ textAlign:"center" }}>
        <button className="hp-btn-g" onClick={onRestart}>↺ Actualizar mi perfil</button>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════
   MAIN APP
═══════════════════════════════════════ */
export default function HealthProfileModule() {
  const [screen, setScreen]       = useState("intro");
  const [answers, setAnswers]     = useState({});
  const [diagnosis, setDiagnosis] = useState(null);
  const [script, setScript]       = useState("");
  const [error, setError]         = useState("");
  const videoTimer = useRef(null);

  useEffect(() => { injectCSS(); }, []);

  /* Analyze profile with Claude */
  const analyze = useCallback(async (ans) => {
    setAnswers(ans);
    setScreen("analyzing");
    try {
      const profileStr = Object.entries(ans).map(([k, v]) =>
        `${k}: ${Array.isArray(v) ? v.join(", ") : v}`
      ).join("\n");

      const raw = await askClaude(
        `Eres el Dr. Smoothie, un experto en nutrición y bienestar alternativo de la plataforma dr.smoothie.ai de JRMB Food Network LLC.
        Analiza el perfil de salud del miembro y genera un diagnóstico de bienestar estructurado en JSON con este formato exacto:
        {
          "wellness_score": número 0-100,
          "summary": "resumen breve del estado general del miembro en 2 oraciones",
          "alerts": [{"icon":"emoji","title":"título","detail":"detalle específico basado en su perfil"}],
          "smoothies": [
            {"emoji":"emoji","name":"nombre creativo del smoothie","ingredients":"ingredientes principales","timing":"momento del día","benefit":"beneficio específico para este miembro"}
          ],
          "avoid": ["ingrediente1","ingrediente2"]
        }
        REGLAS CRÍTICAS:
        - El wellness_score debe ser honesto y basado en los datos reales
        - Los smoothies deben ser 3, ultra personalizados basados en sus condiciones, objetivo, alergias y medicamentos
        - Las alertas deben mencionar ESPECÍFICAMENTE sus condiciones, medicamentos e historial familiar
        - Los ingredientes a evitar deben contemplar ALERGIAS y INTERACCIONES con sus medicamentos
        - NUNCA uses lenguaje de diagnóstico médico: solo "orientación nutricional" y "bienestar alternativo"
        - Incluir disclaimer solo en summary si hay condiciones médicas relevantes
        - Responde SOLO con el JSON, sin markdown, sin explicaciones`,
        `Perfil del miembro:\n${profileStr}`,
        1500
      );

      const parsed = extractJSON(raw);
      if (!parsed) throw new Error("JSON inválido");
      setDiagnosis(parsed);
      setScreen("diagnosis");
    } catch (e) {
      setError("Error al analizar el perfil. Verifica la conexión e intenta de nuevo.");
      setScreen("error");
    }
  }, []);

  /* Generate video script with Claude */
  const generateVideo = useCallback(async () => {
    setScreen("video-generating");
    try {
      const sc = await askClaude(
        `Eres el Dr. Smoothie, el asesor de bienestar AI de dr.smoothie.ai. 
        Genera un guión de video de 90 segundos (aprox 200 palabras) que será narrado por tu avatar HeyGen al miembro.
        ESTRUCTURA: 
        1. Saludo cálido y personal con su nombre (0:00-0:12)
        2. Hallazgos clave de su perfil de forma positiva y motivadora (0:12-0:28)
        3. Por qué es importante NO fallar en seguir el plan (0:28-0:45)
        4. Promesa específica de resultados en 30, 60 y 90 días (0:45-1:10)
        5. Cierre motivador + disclaimer de bienestar (1:10-1:30)
        REGLAS CRÍTICAS:
        - Tono: cálido, profesional, motivador — como un mentor de salud
        - NUNCA menciones "diagnóstico médico", "tratamiento" ni "cura"
        - Usa: "orientación nutricional", "plan de bienestar", "recomendación alternativa"
        - Menciona condiciones familiares y objetivos de forma alentadora, no alarmista
        - Cierra SIEMPRE con: "Recuerda: este plan complementa, nunca reemplaza, la atención de tu médico."
        - El guión debe sonar como una conversación, no como un documento
        Responde SOLO con el guión de voz, sin acotaciones ni instrucciones de dirección.`,
        `Nombre: ${answers.name}. Perfil: objetivo=${Array.isArray(answers.goal)?answers.goal.join(","):answers.goal}, condiciones=${Array.isArray(answers.conditions)?answers.conditions.join(","):answers.conditions}, historial familiar=${Array.isArray(answers.family)?answers.family.join(","):answers.family}, wellness score=${diagnosis?.wellness_score}, plan de smoothies: ${diagnosis?.smoothies?.map(s=>s.name).join(", ")}`,
        800
      );
      setScript(sc.trim());

      /* Simulate HeyGen rendering */
      await new Promise(r => { videoTimer.current = setTimeout(r, 8000); });
      setScreen("video-ready");
    } catch (e) {
      setError("Error al generar el video. Verifica la conexión.");
      setScreen("error");
    }
  }, [answers, diagnosis]);

  const restart = () => {
    setScreen("intro");
    setAnswers({});
    setDiagnosis(null);
    setScript("");
    setError("");
  };

  /* Background canvas */
  const canvasRef = useRef(null);
  useEffect(() => {
    const c = canvasRef.current; if (!c) return;
    const ctx = c.getContext("2d");
    let id, W, H, pts = [];
    const resize = () => { W = c.width = window.innerWidth; H = c.height = window.innerHeight; };
    resize(); window.addEventListener("resize", resize);
    class P {
      constructor() { this.x=Math.random()*W; this.y=Math.random()*H; this.vx=(Math.random()-.5)*.3; this.vy=(Math.random()-.5)*.3; this.r=Math.random()*1.6+.3; this.ph=Math.random()*Math.PI*2; }
      tick() { this.x+=this.vx; this.y+=this.vy; this.ph+=.016; if(this.x<-8||this.x>W+8||this.y<-8||this.y>H+8){this.x=Math.random()*W;this.y=Math.random()*H;} }
      draw() { const a=.09+Math.sin(this.ph)*.05; ctx.beginPath(); ctx.arc(this.x,this.y,this.r,0,Math.PI*2); ctx.fillStyle=`rgba(45,255,140,${a})`; ctx.fill(); }
    }
    for(let i=0;i<90;i++) pts.push(new P());
    const frame = () => {
      ctx.clearRect(0,0,W,H);
      for(let i=0;i<pts.length;i++) for(let j=i+1;j<pts.length;j++) {
        const dx=pts[i].x-pts[j].x,dy=pts[i].y-pts[j].y,d=Math.sqrt(dx*dx+dy*dy);
        if(d<100){ctx.beginPath();ctx.moveTo(pts[i].x,pts[i].y);ctx.lineTo(pts[j].x,pts[j].y);ctx.strokeStyle=`rgba(45,255,140,${(1-d/100)*.07})`;ctx.lineWidth=.5;ctx.stroke();}
      }
      pts.forEach(p=>{p.tick();p.draw();});
      id=requestAnimationFrame(frame);
    };
    frame();
    return () => { cancelAnimationFrame(id); window.removeEventListener("resize",resize); };
  }, []);

  return (
    <>
      {/* Background */}
      <canvas ref={canvasRef} style={{ position:"fixed", inset:0, zIndex:0, opacity:.45, pointerEvents:"none" }} />
      <div style={{ position:"fixed", inset:0, zIndex:1, backgroundImage:`url("data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.02'/%3E%3C/svg%3E")`, pointerEvents:"none" }} />
      {/* Ambient glow */}
      <div style={{ position:"fixed", top:"20%", left:"50%", transform:"translateX(-50%)", width:600, height:600, background:"radial-gradient(ellipse,rgba(45,255,140,0.04) 0%,transparent 70%)", zIndex:0, pointerEvents:"none" }} />

      {/* App */}
      <div style={{ position:"relative", zIndex:2, minHeight:"100vh" }}>
        {screen === "intro"             && <IntroScreen onStart={() => setScreen("wizard")} />}
        {screen === "wizard"            && <WizardScreen onComplete={analyze} />}
        {screen === "analyzing"         && <AnalyzingScreen name={answers.name} />}
        {screen === "diagnosis"         && diagnosis && <DiagnosisScreen diagnosis={diagnosis} answers={answers} onGenerateVideo={generateVideo} />}
        {screen === "video-generating"  && <VideoGeneratingScreen script={script} name={answers.name} />}
        {screen === "video-ready"       && <VideoReadyScreen script={script} name={answers.name} answers={answers} onRestart={restart} />}
        {screen === "error"             && (
          <div style={{ minHeight:"100vh", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:40, textAlign:"center" }}>
            <div style={{ fontSize:48, marginBottom:16 }}>⚠️</div>
            <h2 style={{ fontFamily:"'Syne',sans-serif", fontSize:24, fontWeight:800, color:C.white, marginBottom:8 }}>Error de conexión</h2>
            <p style={{ color:C.muted, marginBottom:24 }}>{error}</p>
            <button className="hp-btn-p" onClick={restart}>↺ Intentar de nuevo</button>
          </div>
        )}
      </div>
    </>
  );
}
